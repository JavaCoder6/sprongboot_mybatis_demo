package com.example.springboot.mybatis.demo.dto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * 营销密度分布统计表(大数据更新)
 * @TableName t_marketing_crowd_frequency_statistics
 */
@Data
public class MarketingCrowdFrequencyStatisticsDto implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 业务线
     */
    private String businessGroup;

    /**
     * 营销次数
     */
    private Integer taskCnt;

    /**
     * 营销人数
     */
    private Integer pTodayTrueNum;

    /**
     * 占营销覆盖人数比例
     */
    private BigDecimal marketRate;

    /**
     * 今日短信促动次数
     */
    private Integer smsTodayNum;

    /**
     * 今日实际短信促动次数
     */
    private Integer smsTodayTrueNum;

    /**
     * 今日push促动次数
     */
    private Integer pushTodayNum;

    /**
     * 今日实际push促动次数
     */
    private Integer pushTodayTrueNum;

    /**
     * 今日ai促动次数
     */
    private Integer aiTodayNum;

    /**
     * 今日实际ai促动次数
     */
    private Integer aiTodayTrueNum;

    /**
     * 短信促动人数
     */
    private Integer smsUser;

    /**
     * puah促动人数
     */
    private Integer pushUser;

    /**
     * ai促动人数
     */
    private Integer aiUser;

    /**
     * 短信触达人数
     */
    private Integer smsTrueUser;

    /**
     * puah触达人数
     */
    private Integer pushTrueUser;

    /**
     * ai触达人数
     */
    private Integer aiTrueUser;

    /**
     * 今日短信触达率促达率
     */
    private BigDecimal smsSuccessRate;

    /**
     * 今日ai触达率促达率
     */
    private BigDecimal aiSuccessRate;

    /**
     * 今日push触达率促达率
     */
    private BigDecimal pushSuccessRate;

    /**
     * 短信促动平均人次
     */
    private BigDecimal smsAvgNum;

    /**
     * push促动平均人次
     */
    private BigDecimal pushAvgNum;

    /**
     * ai促动平均人次
     */
    private BigDecimal aiAvgNum;

    /**
     * 短信触达平均人次
     */
    private BigDecimal smsTrueAvgNum;

    /**
     * push触达平均人次
     */
    private BigDecimal pushTrueAvgNum;

    /**
     * ai触达平均人次
     */
    private BigDecimal aiTrueAvgNum;

    /**
     * 时间
     */
    private String ds;

    /**
     * 分类
     */
    private String tag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createdBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updatedBy;

    /**
     * 软删除位，0表示逻辑删除，1表示使用
     */
    private Integer inUse;

    private static final long serialVersionUID = 1L;
}