package com.example.springboot.mybatis.demo.dao;

import com.example.springboot.mybatis.demo.dto.MarketingCrowdFrequencyStatisticsDto;
import com.example.springboot.mybatis.demo.entity.MarketingCrowdFrequencyStatistics;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
* @author lisifan
* @description 针对表【t_marketing_crowd_frequency_statistics(营销密度分布统计表(大数据更新))】的数据库操作Mapper
* @createDate 2023-07-18 11:19:17
* @Entity generator.domain.MarketingCrowdFrequencyStatistics
*/
@Mapper
public interface MarketingCrowdFrequencyStatisticsMapper {

    int deleteByPrimaryKey(Long id);

    int insert(MarketingCrowdFrequencyStatistics record);

    int insertSelective(MarketingCrowdFrequencyStatistics record);

    MarketingCrowdFrequencyStatistics selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(MarketingCrowdFrequencyStatistics record);

    int updateByPrimaryKey(MarketingCrowdFrequencyStatistics record);

    List<MarketingCrowdFrequencyStatisticsDto> getMore(MarketingCrowdFrequencyStatisticsDto marketingCrowdFrequencyStatisticsDto);

}
