package com.example.springboot.mybatis.demo.crotroller;

import com.example.springboot.mybatis.demo.entity.MarketingCrowdFrequencyStatistics;
import com.example.springboot.mybatis.demo.service.MarketingCrowdFrequencyStatisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * @beLongProjecet: springboot_mybatis_demo
 * @beLongPackage: com.example.springboot_mybatis_demo.crotroller
 * @author: liSiFan
 * @createTime: 2023/07/18 11:25
 * @description:
 * @version: v1.0
 */
@Controller
@RestController
@RequestMapping("my")
public class MarketingCrowdFrequencyStatisticsController {
    @Autowired
    MarketingCrowdFrequencyStatisticsService marketingCrowdFrequencyStatisticsService;

    /**
     * 查询
     *
     * @param marketingPlatformRequest
     * @return
     */
    @PostMapping("/getById")
    @ResponseBody
    public MarketingCrowdFrequencyStatistics queryList(@RequestBody MarketingCrowdFrequencyStatistics marketingPlatformRequest) {

        return marketingCrowdFrequencyStatisticsService.getOne(marketingPlatformRequest);
    }


}
