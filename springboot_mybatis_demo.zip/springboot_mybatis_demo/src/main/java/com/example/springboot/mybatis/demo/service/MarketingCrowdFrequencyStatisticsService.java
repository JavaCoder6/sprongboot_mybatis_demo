package com.example.springboot.mybatis.demo.service;

import com.example.springboot.mybatis.demo.entity.MarketingCrowdFrequencyStatistics;

/**
 * @beLongProjecet: springboot_mybatis_demo
 * @beLongPackage: com.example.springboot_mybatis_demo.service
 * @author: liSiFan
 * @createTime: 2023/07/18 11:22
 * @description:
 * @version: v1.0
 */
public interface MarketingCrowdFrequencyStatisticsService {

    MarketingCrowdFrequencyStatistics getOne(MarketingCrowdFrequencyStatistics marketingCrowdFrequencyStatistics);
}
