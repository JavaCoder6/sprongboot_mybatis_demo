package com.example.springboot.mybatis.demo.service.impl;

import com.example.springboot.mybatis.demo.entity.MarketingCrowdFrequencyStatistics;
import com.example.springboot.mybatis.demo.dao.MarketingCrowdFrequencyStatisticsMapper;
import com.example.springboot.mybatis.demo.service.MarketingCrowdFrequencyStatisticsService;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @beLongProjecet: springboot_mybatis_demo
 * @beLongPackage: com.example.springboot_mybatis_demo.service.impl
 * @author: liSiFan
 * @createTime: 2023/07/18 11:23
 * @description:
 * @version: v1.0
 */
@org.springframework.stereotype.Service
public class MarketingCrowdFrequencyStatisticsServiceImpl implements MarketingCrowdFrequencyStatisticsService {

    @Autowired
    MarketingCrowdFrequencyStatisticsMapper mapper;

    @Override
    public MarketingCrowdFrequencyStatistics getOne(MarketingCrowdFrequencyStatistics marketingCrowdFrequencyStatistics) {
        return mapper.selectByPrimaryKey(marketingCrowdFrequencyStatistics.getId());
    }
}
