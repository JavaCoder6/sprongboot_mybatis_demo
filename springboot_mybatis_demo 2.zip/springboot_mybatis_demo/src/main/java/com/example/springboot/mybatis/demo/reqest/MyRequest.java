package com.example.springboot.mybatis.demo.reqest;

import com.example.springboot.mybatis.demo.dto.MarketingCrowdFrequencyStatisticsDto;
import lombok.Data;

import java.util.List;

/**
 * @beLongProjecet: springboot_mybatis_demo
 * @beLongPackage: com.example.springboot.mybatis.demo.reqest
 * @author: liSiFan
 * @createTime: 2023/07/20 11:12
 * @description: 自我封装的请求
 * @version: v1.0
 */
@Data
public class MyRequest {

    /**
     * 查单个时候使用
     */
    MarketingCrowdFrequencyStatisticsDto marketingCrowdFrequencyStatisticsDto;

    /**
     * 查多个时候使用
     */
    List<MarketingCrowdFrequencyStatisticsDto> marketingCrowdFrequencyStatisticsDtos;

}
