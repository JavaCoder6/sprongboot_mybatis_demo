package com.example.springboot.mybatis.demo.result;

import com.example.springboot.mybatis.demo.dto.MarketingCrowdFrequencyStatisticsDto;
import lombok.Data;

import java.util.List;

/**
 * @beLongProjecet: springboot_mybatis_demo
 * @beLongPackage: com.example.springboot.mybatis.demo.result
 * @author: liSiFan
 * @createTime: 2023/07/20 11:12
 * @description: 自我封装的返回对象
 * @version: v1.0
 */
@Data
public class MyResult {
    /**
     * 返回单个时候使用
     */
    MarketingCrowdFrequencyStatisticsDto marketingCrowdFrequencyStatisticsDto;

    /**
     * 返回多个时候使用
     */
    List<MarketingCrowdFrequencyStatisticsDto> marketingCrowdFrequencyStatisticsDtos;
}
