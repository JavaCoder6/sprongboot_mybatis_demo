package com.example.springboot.mybatis.demo.service;

import com.example.springboot.mybatis.demo.dto.MarketingCrowdFrequencyStatisticsDto;
import com.example.springboot.mybatis.demo.entity.MarketingCrowdFrequencyStatistics;
import com.example.springboot.mybatis.demo.reqest.MyRequest;
import com.example.springboot.mybatis.demo.result.MyResult;

import java.util.List;

/**
 * @beLongProjecet: springboot_mybatis_demo
 * @beLongPackage: com.example.springboot_mybatis_demo.service
 * @author: liSiFan
 * @createTime: 2023/07/18 11:22
 * @description:
 * @version: v1.0
 */
public interface MarketingCrowdFrequencyStatisticsService {

    MarketingCrowdFrequencyStatistics getOne(MarketingCrowdFrequencyStatistics marketingCrowdFrequencyStatistics);

    MyResult getMore(MyRequest marketingCrowdFrequencyStatisticsDto);
}
