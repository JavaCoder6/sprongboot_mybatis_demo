package com.example.springboot.mybatis.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMybatisDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
